#include "ti_msp_dl_config.h"
#include "Light.h"

uint8_t Light_1;
uint8_t Light_2;
uint8_t Light_3;
uint8_t Light_4;
uint8_t Light_5;
uint8_t Light_6;
uint8_t Light_7;
uint8_t Light_8;

void Light_Get(void)
{
   if(!DL_GPIO_readPins(GPIO_Follow_PIN_R3_PORT,GPIO_Follow_PIN_R3_PIN))
       {
         Light_1 = 1;
       }
    else 
       {
          Light_1 = 0;
       }

    if(!DL_GPIO_readPins(GPIO_Follow_PIN_R2_PORT,GPIO_Follow_PIN_R2_PIN))
       {
         Light_2 = 1;
       }
    else 
       {
          Light_2 = 0;
       }

    if(!DL_GPIO_readPins(GPIO_Follow_PIN_R1_PORT,GPIO_Follow_PIN_R1_PIN))
       {
         Light_3 = 1;
       }
    else 
       {
          Light_3 = 0;
       }

        if(!DL_GPIO_readPins(GPIO_Follow_PIN_L1_PORT,GPIO_Follow_PIN_L1_PIN))
       {
         Light_4 = 1;
       }
    else 
       {
          Light_4 = 0;
       }

        if(!DL_GPIO_readPins(GPIO_Follow_PIN_L2_PORT,GPIO_Follow_PIN_L2_PIN))
       {
         Light_5 = 1;
       }
    else 
       {
          Light_5 = 0;
       }

        if(!DL_GPIO_readPins(GPIO_Follow_PIN_L3_PORT,GPIO_Follow_PIN_L3_PIN))
       {
         Light_6 = 1;
       }
    else 
       {
          Light_6 = 0;
       }

        if(!DL_GPIO_readPins(GPIO_Follow_PIN_R4_PORT,GPIO_Follow_PIN_R4_PIN))
       {
         Light_7 = 1;
       }
    else 
       {
          Light_7 = 0;
       }

        if(!DL_GPIO_readPins(GPIO_Follow_PIN_L4_PORT,GPIO_Follow_PIN_L4_PIN))
       {
         Light_8 = 1;
       }
    else 
       {
          Light_8 = 0;
       }

}

































