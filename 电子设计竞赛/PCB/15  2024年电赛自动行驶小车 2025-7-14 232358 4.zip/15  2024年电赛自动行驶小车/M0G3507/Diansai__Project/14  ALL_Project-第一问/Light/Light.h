#ifndef _LIGHT_H__
#define _LIGHT_H__



void Light_Get(void);









#endif










