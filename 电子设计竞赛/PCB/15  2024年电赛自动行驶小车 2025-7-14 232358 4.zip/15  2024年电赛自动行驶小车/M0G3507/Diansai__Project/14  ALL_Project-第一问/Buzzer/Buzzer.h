#ifndef _BUZZER_H__
#define _BUZZER_H__



void Buzzer_Start();
void Buzzer_Stop();





#endif

























