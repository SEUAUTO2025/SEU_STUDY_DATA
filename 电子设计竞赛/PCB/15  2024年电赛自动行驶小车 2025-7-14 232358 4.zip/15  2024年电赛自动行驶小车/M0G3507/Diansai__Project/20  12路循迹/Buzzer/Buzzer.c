#include "ti_msp_dl_config.h"
#include "Buzzer.h"

void Buzzer_Start()
{
  DL_GPIO_clearPins(GPIO_Buzzer_PORT, GPIO_Buzzer_PIN_bilibili_PIN);
  DL_GPIO_setPins(GPIO_LED_PORT, GPIO_LED_PIN_led_PIN);
}

void Buzzer_Stop()
{
  DL_GPIO_setPins(GPIO_Buzzer_PORT, GPIO_Buzzer_PIN_bilibili_PIN);
   DL_GPIO_clearPins(GPIO_LED_PORT, GPIO_LED_PIN_led_PIN);
}






























