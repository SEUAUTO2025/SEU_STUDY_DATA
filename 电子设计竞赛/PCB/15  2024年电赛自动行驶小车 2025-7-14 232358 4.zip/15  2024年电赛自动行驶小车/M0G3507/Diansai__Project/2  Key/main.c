//////////////////////////////////////////////////////////////////////////////////	 
//  文 件 名   : oled.c
//  版 本 号   : v2.0
//  作    者   : Torris
//  生成日期   : 2024-07-08
//  最近修改   : 
//  功能描述   : 0.96寸OLED 接口演示例程(MSPM0G系列)
//  驱动IC     : SSD1306/SSD1315
//              说明: 
//              ----------------------------------------------------------------
//              GND    电源地
//              VCC    接3.3v电源
//              SCL    PA31（时钟）
//              SDA    PA28（数据）    
//******************************************************************************/
#include "ti_msp_dl_config.h"
#include "oled.h"
#include "bmp.h"
#include "board.h"
#include <stdio.h>
#include "bsp_mpu6050.h"
#include "inv_mpu.h"
#include "ultrasonic.h"
#include "string.h"
#include "Key.h"

uint8_t Key_Value;

int main( void )
{
    SYSCFG_DL_init();
    OLED_Init();		//初始化OLED

    while(1) 
    {
       Key_Value = Key_GetValue();
       OLED_ShowString(0, 0, (uint8_t *)"Key:", 16);
       OLED_ShowNum(40,0, Key_Value, 1, 16);
    }
}
