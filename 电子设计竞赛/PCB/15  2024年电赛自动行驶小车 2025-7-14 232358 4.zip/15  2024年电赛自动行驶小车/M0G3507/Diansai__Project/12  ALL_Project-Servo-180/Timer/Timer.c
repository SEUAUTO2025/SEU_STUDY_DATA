#include "ti_msp_dl_config.h"
#include "Timer.h"
#include "Key.h"
#include "bsp_mpu6050.h"
#include "inv_mpu.h"
#include "Pid.h"
#include "Motor.h"
#include "PWM_Car.h"
#include "OPENMV.h"
#include "Servo.h"

int8_t Key_Value;        //按键获取值
int8_t Key_Down,Key_Old; //按键获取值
extern bool Mode;      //模式切换变量,定义在main中
bool Mode_Flag;         //模式切换标志位
bool Motor_Flag;         //电机启动标志位

//int16_t Speed1=120 ,Speed2=120 ;//设置电机默认占空比
int16_t PWM,PWM1,PWM2= 150,PWM3,PWM4=64 ;//设置电机占空比
extern uint8_t Uart0_RxPack[4];//定义缓存区数组
extern volatile int32_t Frount_Left_Count ;
extern volatile int32_t Frount_Right_Count ;
float Angle1=80,Angle2=80;
uint8_t Fast_Count;

extern float pitch,roll,yaw;
extern float yaw_calcu;      //转向理论值
float yaw_measure;    //转向测量值

extern int velocity_calcu; //速度理论值
int velocity;              //速度测量值（编码器脉冲数，非真实速度）



void Timer_G0_10ms_Init()//10ms中断初始化
{
    NVIC_EnableIRQ(TIMER_10ms_INST_INT_IRQN);//使能中断TimerG0
    DL_TimerG_startCounter(TIMER_10ms_INST);//开始记数TimerG0 (10ms)
}

void TIMER_10ms_INST_IRQHandler(void)//中断函数
{
   switch (DL_TimerG_getPendingInterrupt(TIMER_10ms_INST)) //获取TIMER_G0优先级最高的中断
   {
        case DL_TIMER_IIDX_ZERO://Timer G0中断
        
        //小车速度获取（100ms清零一次）
        Fast_Count++;
        if(Fast_Count>=10)
        {
          velocity = (Frount_Left_Count + Frount_Right_Count)/2;
          Frount_Left_Count=0;
          Frount_Right_Count=0;
          Fast_Count=0;
        }
        
        //按键数值读取
	    Key_Value =Key_GetValue();
	    Key_Down = Key_Value & (Key_Old ^ Key_Value);//检测下降沿
        Key_Old = Key_Value;   
        
        if(Key_Down == 1)	
		{	
		   Mode ^= 1;
		   Mode_Flag = 1;
	    }

        if(Key_Down == 2)	
		{	
		   velocity_calcu+=10;
	    } 
        if(Key_Down == 3)	
		{	
		  
	    }
        if(Key_Down == 4)	
		{	
		   Angle2+=5;
          if(Angle2>=170)Angle2 = 90;
          Servo_SetAngle_2(Angle2);
	    }

        //舵机PID计算
         if(Uart0_RxPack[2] == 0)
         {
           Uart0_RxPack[2] = 90;
         }
         if(Uart0_RxPack[0] == 0)
         {
           Uart0_RxPack[0] = 90;
         }

         PWM1	=  PWM2 + turn_PID_value(yaw_calcu,Uart0_RxPack[2]);
		 PWM3	=  PWM4 + turn_PID_value(yaw_calcu,Uart0_RxPack[0]);

        //PWM限幅
        if(PWM1 >= 170) PWM1 = 170;
        if(PWM1 <= 80)  PWM1 = 80;
        PWM2   =  PWM1;
        
        if(PWM3 >= 170) PWM3 = 170;
        if(PWM3 <= 30)  PWM3 =30;
        PWM4   =  PWM3;

        Servo_SetAngle_1(PWM3);	
      	Servo_SetAngle_2(PWM1);			

            break;

        default:
            break;
   }
}



















