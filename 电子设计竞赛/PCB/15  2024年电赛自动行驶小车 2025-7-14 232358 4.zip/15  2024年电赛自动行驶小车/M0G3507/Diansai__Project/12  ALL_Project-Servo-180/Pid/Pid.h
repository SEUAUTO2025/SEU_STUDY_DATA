#ifndef _PID_H__
#define _PID_H__


int turn_PID_value(float yaw_measure,float yaw_calcu);
void PWM_Xianfu(int16_t max,int16_t min,int16_t *PWM1,int16_t *PWM2);
int velocity_PID_value(int velocity,int velocity_calcu);
void I_xianfu(int max,int min);





#endif






























