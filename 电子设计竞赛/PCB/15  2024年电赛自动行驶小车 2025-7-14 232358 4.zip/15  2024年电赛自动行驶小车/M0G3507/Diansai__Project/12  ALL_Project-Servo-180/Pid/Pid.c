#include "ti_msp_dl_config.h"
#include "Pid.h"

extern float VKp,VKi;    //速度环参数
int velocity_CHA;            //速度偏差
float filt_velocity;     //滤波后的速度
float last_filt_velocity;//上一次的滤波后的速度
float velocity_sum=0;    //速度的累加

extern float TKp,TKd;       //转向环参数
float yaw_err;              //角度偏差
float last_yaw_err;         //上次角度偏差    
float yaw_err_difference;   //角度误差的差值

//速度环：
int velocity_PID_value(int velocity,int velocity_calcu)
{
	float a=0.3; 	//滤波系数（反映滤波程度）
	velocity_CHA = velocity - velocity_calcu;                  //速度偏差
	filt_velocity = a*velocity_CHA + (1-a)*last_filt_velocity; //一阶速度滤波
	velocity_sum +=  filt_velocity;                            //速度的累加
	I_xianfu(100,0);                                            //累加限幅
	last_filt_velocity = filt_velocity;                        //此次速度记录为“上次速度”
 
	return VKp*filt_velocity + VKi*velocity_sum;
}

//I限幅：
void I_xianfu(int max,int min)
{
	if(velocity_sum>max)  velocity_sum=max;
	if(velocity_sum<min)  velocity_sum=min;
}



//转向环：
int turn_PID_value(float yaw_measure,float yaw_calcu)
{
	 yaw_err = yaw_measure - yaw_calcu; //转向偏差
	 yaw_err_difference = yaw_err - last_yaw_err;
	 last_yaw_err = yaw_err;
	
 	return TKp * yaw_err + TKd * yaw_err_difference ;
}

//PWM限幅
void PWM_Xianfu(int16_t max,int16_t min,int16_t *PWM1,int16_t *PWM2)
{
	if(*PWM1>max)  *PWM1 = max;
	if(*PWM1<min)  *PWM1 = min;
	if(*PWM2>max)  *PWM2 = max;
	if(*PWM2<min)  *PWM2 = min;
}
























