#include "ti_msp_dl_config.h"
#include "oled.h"
#include "bmp.h"
#include "board.h"
#include <stdio.h>
#include "bsp_mpu6050.h"
#include "inv_mpu.h"
#include "ultrasonic.h"
#include "string.h"
#include "Key.h"
#include "Delay.h"
#include "Timer.h"
#include "PWM_Car.h"
#include "OPENMV.h"
#include "Motor.h"
#include "Pid.h"
#include "Encoder.h"
#include "Servo.h"

bool Mode = 0;               //模式切换变量
extern bool Mode_Flag;         //模式切换标志位
extern bool Motor_Flag;       //电机启动标志位(在mpuexti.c定义)

extern uint8_t Uart0_RxPack[4];//定义缓存区数组
float pitch=5,roll=1,yaw=-1;
uint8_t Count;
extern volatile int32_t Frount_Left_Count ;
extern volatile int32_t Frount_Right_Count ;
extern float Angle1,Angle2;
extern int16_t PWM,PWM1,PWM2,PWM3,PWM4;//设置电机占空比

//速度环PI参数:
float VKp=10,VKi=0; 
int velocity_calcu = 10; //速度理论值
extern int velocity;     //速度测量值（编码器脉冲数，非真实速度）

//转向环PD参数:
float TKp = 0.035,TKd = 0.00;       //转向环参数(舵机)
float yaw_calcu = 64;        //转向理论值(舵机)

int main( void )
{
    SYSCFG_DL_init();
    OLED_Init();//初始化OLED
    OPENMV_Init();
    Encoder_Init();
    board_init();
	MPU6050_Init();
    while( mpu_dmp_init() )
    {
      Delay_ms(1000);
    }
     Run_Right();
     Run_Left();
     PWM_Car_Init();//PWM输出初始化
     Servo_Init();
     Timer_G0_10ms_Init(); 

  while(1) 
   { 
    Count++;
    if(Count>=5)
    {
     __NVIC_DisableIRQ(TIMER_10ms_INST_INT_IRQN);
     mpu_dmp_get_data(&pitch,&roll,&yaw);//获取陀螺仪更新状态
     NVIC_EnableIRQ(TIMER_10ms_INST_INT_IRQN);//使能中断TimerG0
     Count=0;
  
    }
   
     if (Mode == 0)
	  {
		if(Mode_Flag == 1)
		  {
			OLED_Clear();
		    Mode_Flag = 0;
		  }
		Motor_Flag = 0;  
        OLED_ShowANGLE(pitch,roll,yaw);//陀螺仪角度的读取在外部中断服务函数中进行，此处仅进行oled显示
	  }

	 if (Mode == 1)
        {
		 if(Mode_Flag == 1)
		  {
			 OLED_Clear();
			 Mode_Flag = 0;
		  }
		 Motor_Flag = 0;


         OLED_ShowString(0,0, (uint8_t *)"Uary0:", 16);
		 OLED_ShowNum(48, 0, Uart0_RxPack[2], 3, 16); 		
         OLED_ShowNum(48,2, TKd, 3, 16);
         OLED_ShowString(0,2, (uint8_t *)"TKD:", 16);
         OLED_ShowNum(48,4, PWM1, 3, 16);
         OLED_ShowString(0,4, (uint8_t *)"PWM1:", 16);
         OLED_ShowNum(48,6, PWM3, 3, 16);
         OLED_ShowString(0,6, (uint8_t *)"PWM3:", 16);
	   }     
   }
}




