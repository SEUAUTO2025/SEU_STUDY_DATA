#include "ti_msp_dl_config.h"
#include "Timer.h"
#include "Key.h"
#include "bsp_mpu6050.h"
#include "inv_mpu.h"
#include "Pid.h"
#include "Motor.h"
#include "PWM_Car.h"
#include "Light.h"
#include "Buzzer.h"

int8_t Key_Value;        //按键获取值
int8_t Key_Down,Key_Old; //按键获取值
bool Mode_Flag;         //模式切换标志位
bool Motor_Flag;         //电机启动标志位
extern uint8_t Mode;      //模式切换变量(定义在main.c中)

int16_t PWM,PWM1,PWM2;//设置电机占空比
extern int16_t PWM3;//设置电机占空比(定义在main.c中)
extern volatile int32_t Frount_Left_Count ;
extern volatile int32_t Frount_Right_Count ;
float Angle1=80,Angle2=80;
uint8_t Fast_Count;//编码器清零次数

extern float pitch,roll,yaw;//(定义在main.c中)
extern float yaw_calcu; //转向理论值(定义在main.c中)
float yaw_measure;  //转向测量值
extern int16_t yaw_Temp;//(定义在main.c中)


extern int velocity_calcu; //速度理论值(定义在main.c中)
uint16_t velocity;              //速度测量值（编码器脉冲数，非真实速度）

extern uint8_t Light_1;//(定义在Light.c中)
extern uint8_t Light_2;
extern uint8_t Light_3;
extern uint8_t Light_4;
extern uint8_t Light_5;
extern uint8_t Light_6;
extern uint8_t Light_7;
extern uint8_t Light_8;

void Timer_G0_10ms_Init()//10ms中断初始化
{
    NVIC_EnableIRQ(TIMER_10ms_INST_INT_IRQN);//使能中断TimerG0
    DL_TimerG_startCounter(TIMER_10ms_INST);//开始记数TimerG0 (10ms)
}

void TIMER_10ms_INST_IRQHandler(void)//中断函数
{
   switch (DL_TimerG_getPendingInterrupt(TIMER_10ms_INST)) //获取TIMER_G0优先级最高的中断
   {
        case DL_TIMER_IIDX_ZERO://Timer G0中断
        
        //按键数值读取
	    Key_Value =Key_GetValue();
	    Key_Down = Key_Value & (Key_Old ^ Key_Value);//检测下降沿
        Key_Old = Key_Value;  

        //灰度传感器信息获取
        Light_Get();//识别到黑线，输出低电平，灯熄灭

        if(Mode == 1)
        {
         if(Light_1 || Light_2 || Light_3 || Light_4 || Light_5 || Light_6 || Light_7 || Light_8)
          {
          Buzzer_Start();
          Motor_Flag = 0; 
          }
         else 
          {
          Buzzer_Stop();
          Motor_Flag = 1; 
          }
        }
        

        if(Key_Down == 1)	
		{	
		   if(Mode == 1)
           {
            Mode = 0;Buzzer_Stop();
           }
           else 
           {
            Mode = 1;
           }
		   Mode_Flag = 1;
	    }

        if(Key_Down == 2)	
		{
           if(Mode == 2)
           {
            Mode = 0;Buzzer_Stop();
           }
           else 
           {
            Mode = 2;
           }	 
           Mode_Flag = 1;
	    } 

        if(Key_Down == 3)	
		{	
		 
   
	    }

        if(Key_Down == 4)	
		{	
	
      
	    }

    if(Mode == 0)
    {
      //PWM限幅
        PWM_Xianfu(400,0,&PWM1,&PWM2);     
        
        //小车设置占空比
        if(Motor_Flag) //给电机PWM
		 {
	       Right_PWM(PWM2);//设置2个电机占空比
           Left_PWM(PWM1);
	 	 }
		else //关闭电机		          
		{
          Right_PWM(0);//设置2个电机占空比
          Left_PWM(0);
		}		
    }    
        
    if(Mode == 1)
    {
        //PID计算
         yaw_Temp = yaw + 99;
         PWM    = velocity_PID_value(velocity_calcu,0);//速度环
         PWM1	= PWM + turn_PID_value(yaw_Temp,yaw_calcu);//左轮
		 PWM2	= PWM - turn_PID_value(yaw_Temp,yaw_calcu);//右轮

        //PWM限幅
        PWM_Xianfu(400,0,&PWM1,&PWM2);     
        
        //小车设置占空比
        if(Motor_Flag) //给电机PWM
		 {
	       Right_PWM(PWM2);//设置2个电机占空比
           Left_PWM(PWM1);
	 	 }
		else //关闭电机		          
		{
          Right_PWM(0);//设置2个电机占空比
          Left_PWM(0);
		}				
    }
    
    if(Mode == 2)
    {
        //PID计算
         PWM  = velocity_PID_value(velocity_calcu,0);//速度环

        
         if((!Light_1) && (!Light_2) && (!Light_3) && (!Light_6) && (!Light_7) && (!Light_8) && (!Light_4) && (!Light_5))
         {
           Buzzer_Start();
           Motor_Flag = 0; 
         }
        else if(Light_6 || Light_7 || Light_8)
         {
           PWM1	= PWM + PWM3;//左轮
		   PWM2	= PWM - PWM3;//右轮
         }
         else if(Light_1||Light_2||Light_3)
         {
           PWM1	= PWM - PWM3;//左轮
		   PWM2	= PWM + PWM3;//右轮
         }
         else 
         {
           PWM1	= PWM ;//左轮
		   PWM2	= PWM ;//右轮
         }

        //PWM限幅
        PWM_Xianfu(600,0,&PWM1,&PWM2);     
        
        //小车设置占空比
        if(Motor_Flag) //给电机PWM
		 {
	       Right_PWM(PWM2);//设置2个电机占空比
           Left_PWM(PWM1);
	 	 }
		else //关闭电机		          
		{
          Right_PWM(0);//设置2个电机占空比
          Left_PWM(0);
		}				
    }
    




            break;

        default:
            break;
   }
}



















