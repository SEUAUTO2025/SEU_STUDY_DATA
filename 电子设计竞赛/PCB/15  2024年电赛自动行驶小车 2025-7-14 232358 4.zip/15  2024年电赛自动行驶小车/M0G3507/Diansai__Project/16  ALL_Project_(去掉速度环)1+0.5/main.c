#include "ti_msp_dl_config.h"
#include "oled.h"
#include "bmp.h"
#include "board.h"
#include <stdio.h>
#include "bsp_mpu6050.h"
#include "inv_mpu.h"
#include "string.h"
#include "Key.h"
#include "Delay.h"
#include "Timer.h"
#include "PWM_Car.h"
#include "Motor.h"
#include "Pid.h"
#include "Encoder.h"
#include "Light.h"
#include "Buzzer.h"

uint8_t Mode = 0;               //模式切换变量
extern bool Mode_Flag;         //模式切换标志位(在Timer.c定义)
extern bool Motor_Flag;       //电机启动标志位(在Timer.c定义)

float pitch,roll,yaw;
uint8_t Count;
extern volatile int32_t Frount_Left_Count;//(在Timer.c定义)
extern volatile int32_t Frount_Right_Count;//(在Timer.c定义)

//速度环PI参数:
float VKp=20,VKi=0; 
int velocity_calcu = 10; //速度理论值
extern int velocity;     //速度测量值（编码器脉冲数，非真实速度）(在Timer.c定义)
//转向环PD参数:
float TKp = 3.58,TKd = 0;       //转向环参数
float yaw_calcu = 105;        //转向理论值
int16_t yaw_Temp;
//转向光电参数
int16_t PWM3 = 200;//设置电机占空比

int main( void )
{
    SYSCFG_DL_init();
    OLED_Init();//初始化OLED
    Encoder_Init();
    board_init();
	MPU6050_Init();
    while( mpu_dmp_init() )
    {
      Delay_ms(1000);
    }
    Run_Right();
    Run_Left();
    PWM_Car_Init();//PWM输出初始化
    Timer_G0_10ms_Init(); 

  while(1) 
   { 
    Count++;
    if(Count>=3)
    {
     __NVIC_DisableIRQ(TIMER_10ms_INST_INT_IRQN);
     mpu_dmp_get_data(&pitch,&roll,&yaw);//获取陀螺仪更新状态
     NVIC_EnableIRQ(TIMER_10ms_INST_INT_IRQN);//使能中断TimerG0
     Count=0;
  
    }
   
     if (Mode == 0)
	  {
		if(Mode_Flag == 1)
		  {
			OLED_Clear();
		    Mode_Flag = 0;
            Motor_Flag = 0; 
		  }
		 
         OLED_ShowANGLE(pitch,roll,yaw);//陀螺仪角度的读取在外部中断服务函数中进行，此处仅进行oled显示
         OLED_ShowString(0,4, (uint8_t *)"Mode:", 16);
         OLED_ShowNum(56,4, Mode, 3, 16);
	  }

	 if (Mode == 1)
        {
		 if(Mode_Flag == 1)
		  {
			 OLED_Clear();
			 Mode_Flag = 0;
             Motor_Flag = 1;
		  }
          
          OLED_ShowString(0,0, (uint8_t *)"yaw_Temp:", 16);
          OLED_ShowNum(81,0, yaw_Temp, 3, 16);
          OLED_ShowString(0,4, (uint8_t *)"Mode:", 16);
          OLED_ShowNum(56,4, Mode, 3, 16);
        }

	 if (Mode == 2)
        {
		 if(Mode_Flag == 1)
		  {
			 OLED_Clear();
			 Mode_Flag = 0;
             Motor_Flag = 1;  
		  } 
	     
         OLED_ShowString(0,0, (uint8_t *)"yaw_Temp:", 16);
         OLED_ShowNum(81,0, yaw_Temp, 3, 16);
         OLED_ShowString(0,4, (uint8_t *)"Mode:", 16);
         OLED_ShowNum(56,4, Mode, 3, 16);
	   }     
   }
}




