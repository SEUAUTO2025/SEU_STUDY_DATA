#include "ti_msp_dl_config.h"
#include "Timer.h"
#include "Key.h"
#include "bsp_mpu6050.h"
#include "inv_mpu.h"
#include "Pid.h"
#include "Motor.h"
#include "PWM_Car.h"
#include "OPENMV.h"
#include "Servo.h"

int8_t Key_Value;        //按键获取值
int8_t Key_Down,Key_Old; //按键获取值
extern bool Mode;      //模式切换变量,定义在main中
bool Mode_Flag;         //模式切换标志位
bool Motor_Flag;         //电机启动标志位

int16_t Speed1=120 ,Speed2=120 ;//设置电机默认占空比
int16_t PWM1,PWM2;//设置电机占空比
extern uint8_t Uart0_RxPack[4];//定义缓存区数组
extern volatile int32_t Frount_Left_Count ;
extern volatile int32_t Frount_Right_Count ;
float Angle1=80,Angle2=80;
uint8_t Fast_Count;

extern float pitch,roll,yaw;
float yaw_calcu = 64;      //转向理论值
float yaw_measure;    //转向测量值


void Timer_G0_10ms_Init()//10ms中断初始化
{
    NVIC_EnableIRQ(TIMER_10ms_INST_INT_IRQN);//使能中断TimerG0
    DL_TimerG_startCounter(TIMER_10ms_INST);//开始记数TimerG0 (10ms)
}

void TIMER_10ms_INST_IRQHandler(void)//中断函数
{
   switch (DL_TimerG_getPendingInterrupt(TIMER_10ms_INST)) //获取TIMER_G0优先级最高的中断
   {
        case DL_TIMER_IIDX_ZERO://Timer G0中断
        
        //小车速度获取（100ms清零一次）
        Fast_Count++;
        if(Fast_Count>=10)
        {
          Frount_Left_Count=0;
          Frount_Right_Count=0;
          Fast_Count=0;
        }
        
        //按键数值读取
	    Key_Value =Key_GetValue();
	    Key_Down = Key_Value & (Key_Old ^ Key_Value);//检测下降沿
        Key_Old = Key_Value;   
        
        if(Key_Down == 1)	
		{	
		   Mode ^= 1;
		   Mode_Flag = 1;
	    }

        if(Key_Down == 2)	
		{	
		   Speed1+=3;
           Speed2+=3;
	    } 
        if(Key_Down == 3)	
		{	
		  Angle1+=10;
          if(Angle1>=170)Angle1 = 90;
          Servo_SetAngle_1(Angle1);
	    }
        if(Key_Down == 4)	
		{	
		   Angle2+=5;
          if(Angle2>=170)Angle2 = 90;
          Servo_SetAngle_2(Angle2);
	    }

        //PID计算
         PWM1	= Speed1 + turn_PID_value(Uart0_RxPack[0],yaw_calcu);
		 PWM2	= Speed2 - turn_PID_value(Uart0_RxPack[0],yaw_calcu);

        //PWM限幅
        PWM_Xianfu(300,0,&PWM1,&PWM2);     
        
        //小车设置占空比
        if(Motor_Flag) //给电机PWM
		 {
	       Right_PWM(PWM2);//设置2个电机占空比
           Left_PWM(PWM1);
	 	 }
		else //关闭电机		          
		{
          Right_PWM(0);//设置2个电机占空比
          Left_PWM(0);
		}				

            break;

        default:
            break;
   }
}



















