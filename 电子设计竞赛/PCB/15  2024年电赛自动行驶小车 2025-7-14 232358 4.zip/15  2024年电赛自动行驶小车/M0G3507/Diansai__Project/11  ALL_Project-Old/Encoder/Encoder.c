#include "ti_msp_dl_config.h"
#include "Encoder.h"

volatile int32_t Frount_Left_Count = 0;
volatile int32_t Frount_Right_Count = 0;

void Encoder_Init()
{
  NVIC_EnableIRQ(GPIO_Encoder_INT_IRQN);
}

void GROUP1_IRQHandler(void)//外中断函数
{
  uint32_t gpioB = DL_GPIO_getEnabledInterruptStatus(GPIO_Encoder_PORT,GPIO_Encoder_PIN_F1_PIN | GPIO_Encoder_PIN_F3_PIN);
  
  if(gpioB & GPIO_Encoder_PIN_F1_PIN) 
  {
    if(DL_GPIO_readPins(GPIO_Encoder_PORT,GPIO_Encoder_PIN_F2_PIN))
     {
        Frount_Left_Count --;
     }
    else
     {
        Frount_Left_Count ++;
     }
     DL_GPIO_clearInterruptStatus(GPIO_Encoder_PORT,GPIO_Encoder_PIN_F1_PIN);
  }

  if(gpioB & GPIO_Encoder_PIN_F3_PIN) 
  {
    if(DL_GPIO_readPins(GPIO_Encoder_PORT,GPIO_Encoder_PIN_F4_PIN)!=0)
     {
        Frount_Right_Count ++;
     }
    else
     {
        Frount_Right_Count --;
     }
  }
    DL_GPIO_clearInterruptStatus(GPIO_Encoder_PORT,GPIO_Encoder_PIN_F3_PIN);
}
























