#include "ti_msp_dl_config.h"
#include "Motor.h"

void Run_Right()
{
  DL_GPIO_setPins(GPIO_Motor_PIN_Left1_PORT, GPIO_Motor_PIN_Left1_PIN);
  DL_GPIO_clearPins(GPIO_Motor_PIN_Left2_PORT, GPIO_Motor_PIN_Left2_PIN);
}

void Stop_Right()
{
  DL_GPIO_clearPins(GPIO_Motor_PIN_Left1_PORT, GPIO_Motor_PIN_Left1_PIN);
  DL_GPIO_clearPins(GPIO_Motor_PIN_Left2_PORT, GPIO_Motor_PIN_Left2_PIN);
}

void Run_Left()
{
  DL_GPIO_setPins(GPIO_Motor_PIN_Right1_PORT, GPIO_Motor_PIN_Right1_PIN);
  DL_GPIO_clearPins(GPIO_Motor_PIN_Right2_PORT, GPIO_Motor_PIN_Right2_PIN);
}

void Stop_Left()
{
  DL_GPIO_clearPins(GPIO_Motor_PIN_Right1_PORT, GPIO_Motor_PIN_Right1_PIN);
  DL_GPIO_clearPins(GPIO_Motor_PIN_Right2_PORT, GPIO_Motor_PIN_Right2_PIN);
}










