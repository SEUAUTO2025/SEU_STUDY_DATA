#include "ti_msp_dl_config.h"
#include "Timer.h"
#include "Key.h"
#include "bsp_mpu6050.h"
#include "inv_mpu.h"
#include "Pid.h"
#include "Motor.h"
#include "PWM_Car.h"
#include "Light.h"
#include "Buzzer.h"

int8_t Key_Value;        //按键获取值
int8_t Key_Down,Key_Old; //按键获取值
bool Mode_Flag;         //模式切换标志位
bool Motor_Flag;         //电机启动标志位
extern uint8_t Mode;      //模式切换变量(定义在main.c中)
extern uint8_t Light_Count ;      //经过标志点时记录标志位
extern uint8_t JiaoCha_Count ;    //经过标志点时记录标志位(第三问)
uint16_t JiaoCha_Delay ;    //经过等待时间(第三问)

int16_t PWM,PWM1,PWM2;//设置电机占空比
extern int16_t PWM3;//设置电机占空比(定义在main.c中)
extern volatile int32_t Frount_Left_Count ;
extern volatile int32_t Frount_Right_Count ;
float Angle1=80,Angle2=80;
uint16_t Light_Delay;//

extern float pitch,roll,yaw;//(定义在main.c中)
extern float yaw_calcu; //转向理论值(定义在main.c中)
float yaw_measure;  //转向测量值
extern int16_t yaw_Temp;//(定义在main.c中)
int16_t yaw_T;
extern float TKp ,TKd;       //转向环参数
extern float VKp; 

extern int velocity_calcu; //速度理论值(定义在main.c中)
uint16_t velocity;              //速度测量值（编码器脉冲数，非真实速度）

extern uint8_t Light_1;//(定义在Light.c中)
extern uint8_t Light_2;
extern uint8_t Light_3;
extern uint8_t Light_4;
extern uint8_t Light_5;
extern uint8_t Light_6;
extern uint8_t Light_7;
extern uint8_t Light_8;

void Timer_G0_10ms_Init()//10ms中断初始化
{
    NVIC_EnableIRQ(TIMER_10ms_INST_INT_IRQN);//使能中断TimerG0
    DL_TimerG_startCounter(TIMER_10ms_INST);//开始记数TimerG0 (10ms)
}

void TIMER_10ms_INST_IRQHandler(void)//中断函数
{
   switch (DL_TimerG_getPendingInterrupt(TIMER_10ms_INST)) //获取TIMER_G0优先级最高的中断
   {
        case DL_TIMER_IIDX_ZERO://Timer G0中断
        
        //按键数值读取
	    Key_Value =Key_GetValue();
	    Key_Down = Key_Value & (Key_Old ^ Key_Value);//检测下降沿
        Key_Old = Key_Value;  

        //灰度传感器信息获取
        Light_Get();//识别到黑线，输出低电平，灯熄灭

        if(Mode == 1 || ((Mode == 2) && (Light_Count == 0))|| ((Mode == 2) && (Light_Count == 2))|| ((Mode == 3) && (JiaoCha_Count == 0)))
        {
         if(Light_1 || Light_2 || Light_3 || Light_4 || Light_5 || Light_6 || Light_7 || Light_8)
          {
            if(Mode == 1)
             {
                Buzzer_Start();
                Motor_Flag = 0;  
             }
            if(((Mode == 2) && (Light_Count == 0)))
            {     
                Buzzer_Start();
                Motor_Flag = 0; 
                Light_Delay++;
                if(Light_Delay>=50)
                {
                  Light_Count = 1; 
                  Light_Delay = 0; 
                }  
            }
             if(((Mode == 2) && (Light_Count == 2)))
            {     
                Buzzer_Start();
                Motor_Flag = 0; 
                Light_Delay++;
                if(Light_Delay>=50)
                {
                  Light_Count = 3; 
                  Light_Delay = 0; 
               }  
            }
            if(((Mode == 3) && (JiaoCha_Count == 0)))
             {     
                Buzzer_Start();
                Motor_Flag = 0; 
                Light_Delay++;
                if(Light_Delay>=50)
                {
                   JiaoCha_Count = 1; 
                   Light_Delay = 0; 
                }  
             }
          }
        }
        

        if(Key_Down == 1)	
		{	
		   if(Mode == 1)
           {
            Mode = 0;Buzzer_Stop();
           }
           else 
           {
            Mode = 1;
           }
		   Mode_Flag = 1;
	    }

        if(Key_Down == 2)	
		{
           if(Mode == 2)
           {
            Mode = 0;Buzzer_Stop();
           }
           else 
           {
            Mode = 2;Light_Count = 0;
           }	 
           Mode_Flag = 1;
	    } 

        if(Key_Down == 3)	
		{	
		 if(Mode == 3)
           {
            Mode = 0;Buzzer_Stop();
           }
           else 
           {
            Mode = 3;JiaoCha_Count = 0;
           }	 
           Mode_Flag = 1;

	    }

        if(Key_Down == 4)	
		{	
	
      
	    }

    if(Mode == 0)
    {
      //PID计算
         yaw_Temp = yaw + 99;
         PWM    = velocity_PID_value(velocity_calcu,0);//速度环
         PWM1	= PWM + turn_PID_value(yaw_Temp,yaw_calcu);//左轮
		 PWM2	= PWM - turn_PID_value(yaw_Temp,yaw_calcu);//右轮

        //PWM限幅
        PWM_Xianfu(400,0,&PWM1,&PWM2);     
        
        //小车设置占空比
        if(Motor_Flag) //给电机PWM
		 {
	       Right_PWM(PWM2);//设置2个电机占空比
           Left_PWM(PWM1);
	 	 }
		else //关闭电机		          
		{
          Right_PWM(0);//设置2个电机占空比
          Left_PWM(0);
		}			
    }    
        
    if(Mode == 1)
    {
        //PID计算
         yaw_Temp = yaw + 99;
         PWM    = velocity_PID_value(velocity_calcu,0);//速度环
         PWM1	= PWM + turn_PID_value(yaw_Temp,yaw_calcu);//左轮
		 PWM2	= PWM - turn_PID_value(yaw_Temp,yaw_calcu);//右轮

        //PWM限幅
        PWM_Xianfu(400,0,&PWM1,&PWM2);     
        
        //小车设置占空比
        if(Motor_Flag) //给电机PWM
		 {
	       Right_PWM(PWM2);//设置2个电机占空比
           Left_PWM(PWM1);
	 	 }
		else //关闭电机		          
		{
          Right_PWM(0);//设置2个电机占空比
          Left_PWM(0);
		}				
    }
    
    if(Mode == 2)
    {
       if(Light_Count == 0)
       {
         //PID计算
         yaw_Temp = yaw + 99;
         PWM    = velocity_PID_value(velocity_calcu,0);//速度环
         PWM1	= PWM + turn_PID_value(yaw_Temp,yaw_calcu);//左轮
		 PWM2	= PWM - turn_PID_value(yaw_Temp,yaw_calcu);//右轮

        //PWM限幅
        PWM_Xianfu(400,0,&PWM1,&PWM2);     
        
        //小车设置占空比
        if(Motor_Flag) //给电机PWM
		 {
	       Right_PWM(PWM2);//设置2个电机占空比
           Left_PWM(PWM1);
	 	 }
		else //关闭电机		          
		{
          Right_PWM(0);//设置2个电机占空比
          Left_PWM(0);
		}		
       }     

     if(Light_Count == 1)
       {
          Buzzer_Stop();
          Motor_Flag = 1; 
         //PID计算
         PWM  = velocity_PID_value(velocity_calcu,0);//速度环

         if((!Light_1) && (!Light_2) && (!Light_3) && (!Light_6) && (!Light_7) && (!Light_8) && (!Light_4) && (!Light_5))
         {
           Buzzer_Start();
           Motor_Flag = 0; 
           if(((Mode == 2) && (Light_Count == 1)))
            {     
                Buzzer_Start();
                Motor_Flag = 0; 
                Light_Delay++;
                if(Light_Delay>=50)
                {
                  Light_Count = 2; 
                  Motor_Flag = 1;
                  Buzzer_Stop();
                  Light_Delay = 0; 
                }  
            }
         }
        else if(Light_6 || Light_7 || Light_8)
         {
           PWM1	= PWM + PWM3;//左轮
		   PWM2	= PWM - PWM3;//右轮
         }
         else if(Light_1||Light_2||Light_3)
         {
           PWM1	= PWM - PWM3;//左轮
		   PWM2	= PWM + PWM3;//右轮
         }
         else 
         {
           PWM1	= PWM ;//左轮
		   PWM2	= PWM ;//右轮
         }

        //PWM限幅
        PWM_Xianfu(600,0,&PWM1,&PWM2);     
        
        //小车设置占空比
        if(Motor_Flag) //给电机PWM
		 {
	       Right_PWM(PWM2);//设置2个电机占空比
           Left_PWM(PWM1);
	 	 }
		else //关闭电机		          
		{
          Right_PWM(0);//设置2个电机占空比
          Left_PWM(0);
		}				
       }

      if(Light_Count == 2)  
       {
        yaw_calcu = 9;
        TKp = 2.3;
         // VKp = 20;

        yaw_T = yaw;
        if(yaw_T < 0 )
        {
              yaw_Temp = yaw_T+179 ; 
        }
       else
        {
            yaw_Temp = yaw_T-179 ;
        }
        //PID计算
        
        
        PWM     = velocity_PID_value(velocity_calcu,0);//速度环
        PWM1	= PWM + turn_PID_value(yaw_Temp,yaw_calcu);//左轮
		PWM2	= PWM - turn_PID_value(yaw_Temp,yaw_calcu);//右轮

        //PWM限幅
        PWM_Xianfu(400,0,&PWM1,&PWM2);     
        
        //小车设置占空比
        if(Motor_Flag) //给电机PWM
		 {
	       Right_PWM(PWM2);//设置2个电机占空比
           Left_PWM(PWM1);
	 	 }
		else //关闭电机		          
		{
          Right_PWM(0);//设置2个电机占空比
          Left_PWM(0);
		}			

       }

      if(Light_Count == 3)
      {
         Buzzer_Stop();
         Motor_Flag = 1; 
         TKp = 2.4;
         //PID计算
         PWM  = velocity_PID_value(velocity_calcu,0);//速度环

         if((!Light_1) && (!Light_2) && (!Light_3) && (!Light_6) && (!Light_7) && (!Light_8) && (!Light_4) && (!Light_5))
         {
           Buzzer_Start();
           Motor_Flag = 0; 
         }
        else if(Light_1||Light_2||Light_3)
         {
           PWM1	= PWM - PWM3;//左轮
		   PWM2	= PWM + PWM3;//右轮
         }
        else if(Light_6 || Light_7 || Light_8)
         {
           PWM1	= PWM + PWM3;//左轮
		   PWM2	= PWM - PWM3;//右轮
         }
         else 
         {
           PWM1	= PWM ;//左轮
		   PWM2	= PWM ;//右轮
         }

        //PWM限幅
        PWM_Xianfu(600,0,&PWM1,&PWM2);     
        
        //小车设置占空比
        if(Motor_Flag) //给电机PWM
		 {
	       Right_PWM(PWM2);//设置2个电机占空比
           Left_PWM(PWM1);
	 	 }
		else //关闭电机		          
		{
          Right_PWM(0);//设置2个电机占空比
          Left_PWM(0);
		}				

      }
    }


    if(Mode == 3)
    {
      if(JiaoCha_Count == 0)
       {
        JiaoCha_Delay++;
        if(JiaoCha_Delay <= 250)                             //直线前进
         {
          //PID计算
          yaw_Temp = yaw + 99;
          PWM    = velocity_PID_value(velocity_calcu,0);//速度环
          PWM1	= PWM + turn_PID_value(yaw_Temp,yaw_calcu);//左轮
		  PWM2	= PWM - turn_PID_value(yaw_Temp,yaw_calcu);//右轮
         }
         if((JiaoCha_Delay> 250)&&(JiaoCha_Delay <320))       //右转
         {
           //PID计算
           yaw_Temp = yaw + 99;       
           TKp = 2.5;
           VKp = 0;
         
           PWM    = velocity_PID_value(velocity_calcu,0);//速度环
           PWM1	= PWM + turn_PID_value(yaw_Temp,15);//左轮
		   PWM2	= PWM - turn_PID_value(yaw_Temp,15);//右轮
         }
         if((JiaoCha_Delay > 320)&&(JiaoCha_Delay < 640))    //右直行
         {
           yaw_Temp = yaw + 99; 
           TKp = 0.5;
           VKp = 20;

           PWM    = velocity_PID_value(velocity_calcu,0);//速度环
           PWM1	= PWM + turn_PID_value(yaw_Temp,30);//左轮
		   PWM2	= PWM - turn_PID_value(yaw_Temp,30);//右轮
         }
         if((JiaoCha_Delay> 640)&&(JiaoCha_Delay < 710))   //左转
         {
           //PID计算
           yaw_Temp = yaw + 99;       
           TKp = 2.5;
           VKp = 0;
           
           PWM    = velocity_PID_value(velocity_calcu,0);//速度环
           PWM1	= PWM + turn_PID_value(yaw_Temp,101);//左轮
		   PWM2	= PWM - turn_PID_value(yaw_Temp,101);//右轮
         }
         if(JiaoCha_Delay >= 720)   // 左转前行
          {
            TKp = 1;
            VKp = 15;
            //PID计算
            yaw_Temp = yaw + 99;
            PWM    = velocity_PID_value(velocity_calcu,0);//速度环
            PWM1	= PWM + turn_PID_value(yaw_Temp,99);//左轮
		    PWM2	= PWM - turn_PID_value(yaw_Temp,99);//右轮
          }

        //PWM限幅
        PWM_Xianfu(400,0,&PWM1,&PWM2);     
        
        //小车设置占空比
        if(Motor_Flag) //给电机PWM
		 {
	       Right_PWM(PWM2);//设置2个电机占空比
           Left_PWM(PWM1);
	 	 }
		else //关闭电机		          
		 {
          Right_PWM(0);//设置2个电机占空比
          Left_PWM(0);
		 }		
       } 

       if (JiaoCha_Count == 1)
       {
          yaw_Temp = yaw + 99; 
          Buzzer_Stop();
          Motor_Flag = 1; 
          TKp = 2.4;
          VKp = 18;
          PWM3 = 150;
         //PID计算
         PWM  = velocity_PID_value(velocity_calcu,0);//速度环

         if((!Light_1) && (!Light_2) && (!Light_3) && (!Light_6) && (!Light_7) && (!Light_8) && (!Light_4) && (!Light_5))
         {
           Buzzer_Start();
           Motor_Flag = 0; 
           if(((Mode == 3) && (JiaoCha_Count == 1)))
            {     
                Buzzer_Start();
                Motor_Flag = 0; 
                Light_Delay++;
                if(Light_Delay>=50)
                 {
                  JiaoCha_Count = 2; 
                  Motor_Flag = 1;
                  Buzzer_Stop();
                  Light_Delay = 0; 
                 }  
            }
         }
         else if(Light_1||Light_2||Light_3)
         {
           PWM1	= PWM - PWM3;//左轮
		   PWM2	= PWM + PWM3;//右轮
         }
        else if(Light_6 || Light_7 || Light_8)
         {
           PWM1	= PWM + PWM3;//左轮
		   PWM2	= PWM - PWM3;//右轮
         }
         
         else 
         {
           PWM1	= PWM ;//左轮
		   PWM2	= PWM ;//右轮
         }

        //PWM限幅
        PWM_Xianfu(600,0,&PWM1,&PWM2);     
        
        //小车设置占空比
        if(Motor_Flag) //给电机PWM
		 {
	       Right_PWM(PWM2);//设置2个电机占空比
           Left_PWM(PWM1);
	 	 }
		else //关闭电机		          
		{
          Right_PWM(0);//设置2个电机占空比
          Left_PWM(0);
		}	

       }



    }












            break;

        default:
            break;
   }
}



















