#ifndef _MOTOR_H__
#define _MOTOR_H__



void Run_Right();
void Stop_Right();
void Run_Left();
void Stop_Left();



#endif















