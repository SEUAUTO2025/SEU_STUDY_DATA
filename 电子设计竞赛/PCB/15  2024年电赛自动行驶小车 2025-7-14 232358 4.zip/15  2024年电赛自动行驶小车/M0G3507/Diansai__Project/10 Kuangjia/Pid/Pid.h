#ifndef _PID_H__
#define _PID_H__


int turn_PID_value(float yaw_measure,float yaw_calcu);
void PWM_Xianfu(int16_t max,int16_t min,int16_t *PWM1,int16_t *PWM2);






#endif






























