#include "ti_msp_dl_config.h"
#include "Pid.h"

extern float TKp,TKd;       //转向环参数
float yaw_err;              //角度偏差
float last_yaw_err;         //上次角度偏差    
float yaw_err_difference;   //角度误差的差值

//转向环：
int turn_PID_value(float yaw_measure,float yaw_calcu)
{
	 yaw_err = yaw_measure - yaw_calcu; //转向偏差
	 yaw_err_difference = yaw_err - last_yaw_err;
	 last_yaw_err = yaw_err;
	
 	return TKp * yaw_err + TKd * yaw_err_difference ;
}

//PWM限幅
void PWM_Xianfu(int16_t max,int16_t min,int16_t *PWM1,int16_t *PWM2)
{
	if(*PWM1>max)  *PWM1 = max;
	if(*PWM1<min)  *PWM1 = min;
	if(*PWM2>max)  *PWM2 = max;
	if(*PWM2<min)  *PWM2 = min;
}
























