/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)


#define CPUCLK_FREQ                                                     32000000



/* Defines for PWM_Car */
#define PWM_Car_INST                                                       TIMA0
#define PWM_Car_INST_IRQHandler                                 TIMA0_IRQHandler
#define PWM_Car_INST_INT_IRQN                                   (TIMA0_INT_IRQn)
#define PWM_Car_INST_CLK_FREQ                                           32000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_Car_C0_PORT                                               GPIOB
#define GPIO_PWM_Car_C0_PIN                                        DL_GPIO_PIN_8
#define GPIO_PWM_Car_C0_IOMUX                                    (IOMUX_PINCM25)
#define GPIO_PWM_Car_C0_IOMUX_FUNC                   IOMUX_PINCM25_PF_TIMA0_CCP0
#define GPIO_PWM_Car_C0_IDX                                  DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_Car_C1_PORT                                               GPIOB
#define GPIO_PWM_Car_C1_PIN                                        DL_GPIO_PIN_9
#define GPIO_PWM_Car_C1_IOMUX                                    (IOMUX_PINCM26)
#define GPIO_PWM_Car_C1_IOMUX_FUNC                   IOMUX_PINCM26_PF_TIMA0_CCP1
#define GPIO_PWM_Car_C1_IDX                                  DL_TIMER_CC_1_INDEX

/* Defines for PWM_Sg */
#define PWM_Sg_INST                                                        TIMA1
#define PWM_Sg_INST_IRQHandler                                  TIMA1_IRQHandler
#define PWM_Sg_INST_INT_IRQN                                    (TIMA1_INT_IRQn)
#define PWM_Sg_INST_CLK_FREQ                                             1000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_Sg_C0_PORT                                                GPIOB
#define GPIO_PWM_Sg_C0_PIN                                        DL_GPIO_PIN_26
#define GPIO_PWM_Sg_C0_IOMUX                                     (IOMUX_PINCM57)
#define GPIO_PWM_Sg_C0_IOMUX_FUNC                    IOMUX_PINCM57_PF_TIMA1_CCP0
#define GPIO_PWM_Sg_C0_IDX                                   DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_Sg_C1_PORT                                                GPIOB
#define GPIO_PWM_Sg_C1_PIN                                        DL_GPIO_PIN_27
#define GPIO_PWM_Sg_C1_IOMUX                                     (IOMUX_PINCM58)
#define GPIO_PWM_Sg_C1_IOMUX_FUNC                    IOMUX_PINCM58_PF_TIMA1_CCP1
#define GPIO_PWM_Sg_C1_IDX                                   DL_TIMER_CC_1_INDEX



/* Defines for TIMER_Ultrasonic */
#define TIMER_Ultrasonic_INST                                            (TIMG6)
#define TIMER_Ultrasonic_INST_IRQHandler                        TIMG6_IRQHandler
#define TIMER_Ultrasonic_INST_INT_IRQN                          (TIMG6_INT_IRQn)
#define TIMER_Ultrasonic_INST_LOAD_VALUE                                (24999U)
/* Defines for TIMER_10ms */
#define TIMER_10ms_INST                                                  (TIMG0)
#define TIMER_10ms_INST_IRQHandler                              TIMG0_IRQHandler
#define TIMER_10ms_INST_INT_IRQN                                (TIMG0_INT_IRQn)
#define TIMER_10ms_INST_LOAD_VALUE                                       (1249U)




/* Defines for I2C_OLED */
#define I2C_OLED_INST                                                       I2C0
#define I2C_OLED_INST_IRQHandler                                 I2C0_IRQHandler
#define I2C_OLED_INST_INT_IRQN                                     I2C0_INT_IRQn
#define I2C_OLED_BUS_SPEED_HZ                                             400000
#define GPIO_I2C_OLED_SDA_PORT                                             GPIOA
#define GPIO_I2C_OLED_SDA_PIN                                     DL_GPIO_PIN_28
#define GPIO_I2C_OLED_IOMUX_SDA                                   (IOMUX_PINCM3)
#define GPIO_I2C_OLED_IOMUX_SDA_FUNC                    IOMUX_PINCM3_PF_I2C0_SDA
#define GPIO_I2C_OLED_SCL_PORT                                             GPIOA
#define GPIO_I2C_OLED_SCL_PIN                                     DL_GPIO_PIN_31
#define GPIO_I2C_OLED_IOMUX_SCL                                   (IOMUX_PINCM6)
#define GPIO_I2C_OLED_IOMUX_SCL_FUNC                    IOMUX_PINCM6_PF_I2C0_SCL

/* Defines for I2C_MPU6050 */
#define I2C_MPU6050_INST                                                    I2C1
#define I2C_MPU6050_INST_IRQHandler                              I2C1_IRQHandler
#define I2C_MPU6050_INST_INT_IRQN                                  I2C1_INT_IRQn
#define I2C_MPU6050_BUS_SPEED_HZ                                          100000
#define GPIO_I2C_MPU6050_SDA_PORT                                          GPIOB
#define GPIO_I2C_MPU6050_SDA_PIN                                   DL_GPIO_PIN_3
#define GPIO_I2C_MPU6050_IOMUX_SDA                               (IOMUX_PINCM16)
#define GPIO_I2C_MPU6050_IOMUX_SDA_FUNC                IOMUX_PINCM16_PF_I2C1_SDA
#define GPIO_I2C_MPU6050_SCL_PORT                                          GPIOB
#define GPIO_I2C_MPU6050_SCL_PIN                                   DL_GPIO_PIN_2
#define GPIO_I2C_MPU6050_IOMUX_SCL                               (IOMUX_PINCM15)
#define GPIO_I2C_MPU6050_IOMUX_SCL_FUNC                IOMUX_PINCM15_PF_I2C1_SCL


/* Defines for UART_0 */
#define UART_0_INST                                                        UART0
#define UART_0_INST_IRQHandler                                  UART0_IRQHandler
#define UART_0_INST_INT_IRQN                                      UART0_INT_IRQn
#define GPIO_UART_0_RX_PORT                                                GPIOB
#define GPIO_UART_0_TX_PORT                                                GPIOB
#define GPIO_UART_0_RX_PIN                                         DL_GPIO_PIN_1
#define GPIO_UART_0_TX_PIN                                         DL_GPIO_PIN_0
#define GPIO_UART_0_IOMUX_RX                                     (IOMUX_PINCM13)
#define GPIO_UART_0_IOMUX_TX                                     (IOMUX_PINCM12)
#define GPIO_UART_0_IOMUX_RX_FUNC                      IOMUX_PINCM13_PF_UART0_RX
#define GPIO_UART_0_IOMUX_TX_FUNC                      IOMUX_PINCM12_PF_UART0_TX
#define UART_0_BAUD_RATE                                                  (9600)
#define UART_0_IBRD_32_MHZ_9600_BAUD                                       (208)
#define UART_0_FBRD_32_MHZ_9600_BAUD                                        (21)
/* Defines for UART_1 */
#define UART_1_INST                                                        UART1
#define UART_1_INST_IRQHandler                                  UART1_IRQHandler
#define UART_1_INST_INT_IRQN                                      UART1_INT_IRQn
#define GPIO_UART_1_RX_PORT                                                GPIOB
#define GPIO_UART_1_TX_PORT                                                GPIOA
#define GPIO_UART_1_RX_PIN                                         DL_GPIO_PIN_5
#define GPIO_UART_1_TX_PIN                                        DL_GPIO_PIN_17
#define GPIO_UART_1_IOMUX_RX                                     (IOMUX_PINCM18)
#define GPIO_UART_1_IOMUX_TX                                     (IOMUX_PINCM39)
#define GPIO_UART_1_IOMUX_RX_FUNC                      IOMUX_PINCM18_PF_UART1_RX
#define GPIO_UART_1_IOMUX_TX_FUNC                      IOMUX_PINCM39_PF_UART1_TX
#define UART_1_BAUD_RATE                                                  (9600)
#define UART_1_IBRD_32_MHZ_9600_BAUD                                       (208)
#define UART_1_FBRD_32_MHZ_9600_BAUD                                        (21)
/* Defines for UART_2 */
#define UART_2_INST                                                        UART2
#define UART_2_INST_IRQHandler                                  UART2_IRQHandler
#define UART_2_INST_INT_IRQN                                      UART2_INT_IRQn
#define GPIO_UART_2_RX_PORT                                                GPIOB
#define GPIO_UART_2_TX_PORT                                                GPIOB
#define GPIO_UART_2_RX_PIN                                        DL_GPIO_PIN_18
#define GPIO_UART_2_TX_PIN                                        DL_GPIO_PIN_17
#define GPIO_UART_2_IOMUX_RX                                     (IOMUX_PINCM44)
#define GPIO_UART_2_IOMUX_TX                                     (IOMUX_PINCM43)
#define GPIO_UART_2_IOMUX_RX_FUNC                      IOMUX_PINCM44_PF_UART2_RX
#define GPIO_UART_2_IOMUX_TX_FUNC                      IOMUX_PINCM43_PF_UART2_TX
#define UART_2_BAUD_RATE                                                  (9600)
#define UART_2_IBRD_32_MHZ_9600_BAUD                                       (208)
#define UART_2_FBRD_32_MHZ_9600_BAUD                                        (21)
/* Defines for UART_3 */
#define UART_3_INST                                                        UART3
#define UART_3_INST_IRQHandler                                  UART3_IRQHandler
#define UART_3_INST_INT_IRQN                                      UART3_INT_IRQn
#define GPIO_UART_3_RX_PORT                                                GPIOA
#define GPIO_UART_3_TX_PORT                                                GPIOA
#define GPIO_UART_3_RX_PIN                                        DL_GPIO_PIN_25
#define GPIO_UART_3_TX_PIN                                        DL_GPIO_PIN_14
#define GPIO_UART_3_IOMUX_RX                                     (IOMUX_PINCM55)
#define GPIO_UART_3_IOMUX_TX                                     (IOMUX_PINCM36)
#define GPIO_UART_3_IOMUX_RX_FUNC                      IOMUX_PINCM55_PF_UART3_RX
#define GPIO_UART_3_IOMUX_TX_FUNC                      IOMUX_PINCM36_PF_UART3_TX
#define UART_3_BAUD_RATE                                                  (9600)
#define UART_3_IBRD_32_MHZ_9600_BAUD                                       (208)
#define UART_3_FBRD_32_MHZ_9600_BAUD                                        (21)





/* Port definition for Pin Group GPIO_Buzzer */
#define GPIO_Buzzer_PORT                                                 (GPIOB)

/* Defines for PIN_bilibili: GPIOB.20 with pinCMx 48 on package pin 19 */
#define GPIO_Buzzer_PIN_bilibili_PIN                            (DL_GPIO_PIN_20)
#define GPIO_Buzzer_PIN_bilibili_IOMUX                           (IOMUX_PINCM48)
/* Port definition for Pin Group GPIO_Ultrasonic */
#define GPIO_Ultrasonic_PORT                                             (GPIOA)

/* Defines for PIN_Trig: GPIOA.12 with pinCMx 34 on package pin 5 */
#define GPIO_Ultrasonic_PIN_Trig_PIN                            (DL_GPIO_PIN_12)
#define GPIO_Ultrasonic_PIN_Trig_IOMUX                           (IOMUX_PINCM34)
/* Defines for PIN_Echo: GPIOA.13 with pinCMx 35 on package pin 6 */
#define GPIO_Ultrasonic_PIN_Echo_PIN                            (DL_GPIO_PIN_13)
#define GPIO_Ultrasonic_PIN_Echo_IOMUX                           (IOMUX_PINCM35)
/* Port definition for Pin Group GPIO_Key */
#define GPIO_Key_PORT                                                    (GPIOB)

/* Defines for PIN_S1: GPIOB.21 with pinCMx 49 on package pin 20 */
#define GPIO_Key_PIN_S1_PIN                                     (DL_GPIO_PIN_21)
#define GPIO_Key_PIN_S1_IOMUX                                    (IOMUX_PINCM49)
/* Defines for PIN_S2: GPIOB.13 with pinCMx 30 on package pin 1 */
#define GPIO_Key_PIN_S2_PIN                                     (DL_GPIO_PIN_13)
#define GPIO_Key_PIN_S2_IOMUX                                    (IOMUX_PINCM30)
/* Defines for PIN_S3: GPIOB.22 with pinCMx 50 on package pin 21 */
#define GPIO_Key_PIN_S3_PIN                                     (DL_GPIO_PIN_22)
#define GPIO_Key_PIN_S3_IOMUX                                    (IOMUX_PINCM50)
/* Defines for PIN_S4: GPIOB.15 with pinCMx 32 on package pin 3 */
#define GPIO_Key_PIN_S4_PIN                                     (DL_GPIO_PIN_15)
#define GPIO_Key_PIN_S4_IOMUX                                    (IOMUX_PINCM32)
/* Defines for PIN_Left1: GPIOB.16 with pinCMx 33 on package pin 4 */
#define GPIO_Motor_PIN_Left1_PORT                                        (GPIOB)
#define GPIO_Motor_PIN_Left1_PIN                                (DL_GPIO_PIN_16)
#define GPIO_Motor_PIN_Left1_IOMUX                               (IOMUX_PINCM33)
/* Defines for PIN_Left2: GPIOB.4 with pinCMx 17 on package pin 52 */
#define GPIO_Motor_PIN_Left2_PORT                                        (GPIOB)
#define GPIO_Motor_PIN_Left2_PIN                                 (DL_GPIO_PIN_4)
#define GPIO_Motor_PIN_Left2_IOMUX                               (IOMUX_PINCM17)
/* Defines for PIN_Right1: GPIOA.15 with pinCMx 37 on package pin 8 */
#define GPIO_Motor_PIN_Right1_PORT                                       (GPIOA)
#define GPIO_Motor_PIN_Right1_PIN                               (DL_GPIO_PIN_15)
#define GPIO_Motor_PIN_Right1_IOMUX                              (IOMUX_PINCM37)
/* Defines for PIN_Right2: GPIOB.7 with pinCMx 24 on package pin 59 */
#define GPIO_Motor_PIN_Right2_PORT                                       (GPIOB)
#define GPIO_Motor_PIN_Right2_PIN                                (DL_GPIO_PIN_7)
#define GPIO_Motor_PIN_Right2_IOMUX                              (IOMUX_PINCM24)
/* Port definition for Pin Group GPIO_Encoder */
#define GPIO_Encoder_PORT                                                (GPIOB)

/* Defines for PIN_F1: GPIOB.10 with pinCMx 27 on package pin 62 */
// pins affected by this interrupt request:["PIN_F1","PIN_F3"]
#define GPIO_Encoder_INT_IRQN                                   (GPIOB_INT_IRQn)
#define GPIO_Encoder_INT_IIDX                   (DL_INTERRUPT_GROUP1_IIDX_GPIOB)
#define GPIO_Encoder_PIN_F1_IIDX                            (DL_GPIO_IIDX_DIO10)
#define GPIO_Encoder_PIN_F1_PIN                                 (DL_GPIO_PIN_10)
#define GPIO_Encoder_PIN_F1_IOMUX                                (IOMUX_PINCM27)
/* Defines for PIN_F2: GPIOB.11 with pinCMx 28 on package pin 63 */
#define GPIO_Encoder_PIN_F2_PIN                                 (DL_GPIO_PIN_11)
#define GPIO_Encoder_PIN_F2_IOMUX                                (IOMUX_PINCM28)
/* Defines for PIN_F3: GPIOB.12 with pinCMx 29 on package pin 64 */
#define GPIO_Encoder_PIN_F3_IIDX                            (DL_GPIO_IIDX_DIO12)
#define GPIO_Encoder_PIN_F3_PIN                                 (DL_GPIO_PIN_12)
#define GPIO_Encoder_PIN_F3_IOMUX                                (IOMUX_PINCM29)
/* Defines for PIN_F4: GPIOB.19 with pinCMx 45 on package pin 16 */
#define GPIO_Encoder_PIN_F4_PIN                                 (DL_GPIO_PIN_19)
#define GPIO_Encoder_PIN_F4_IOMUX                                (IOMUX_PINCM45)
/* Defines for PIN_R3: GPIOA.7 with pinCMx 14 on package pin 49 */
#define GPIO_Follow_PIN_R3_PORT                                          (GPIOA)
#define GPIO_Follow_PIN_R3_PIN                                   (DL_GPIO_PIN_7)
#define GPIO_Follow_PIN_R3_IOMUX                                 (IOMUX_PINCM14)
/* Defines for PIN_R2: GPIOA.8 with pinCMx 19 on package pin 54 */
#define GPIO_Follow_PIN_R2_PORT                                          (GPIOA)
#define GPIO_Follow_PIN_R2_PIN                                   (DL_GPIO_PIN_8)
#define GPIO_Follow_PIN_R2_IOMUX                                 (IOMUX_PINCM19)
/* Defines for PIN_R1: GPIOA.24 with pinCMx 54 on package pin 25 */
#define GPIO_Follow_PIN_R1_PORT                                          (GPIOA)
#define GPIO_Follow_PIN_R1_PIN                                  (DL_GPIO_PIN_24)
#define GPIO_Follow_PIN_R1_IOMUX                                 (IOMUX_PINCM54)
/* Defines for PIN_L1: GPIOB.6 with pinCMx 23 on package pin 58 */
#define GPIO_Follow_PIN_L1_PORT                                          (GPIOB)
#define GPIO_Follow_PIN_L1_PIN                                   (DL_GPIO_PIN_6)
#define GPIO_Follow_PIN_L1_IOMUX                                 (IOMUX_PINCM23)
/* Defines for PIN_L2: GPIOA.26 with pinCMx 59 on package pin 30 */
#define GPIO_Follow_PIN_L2_PORT                                          (GPIOA)
#define GPIO_Follow_PIN_L2_PIN                                  (DL_GPIO_PIN_26)
#define GPIO_Follow_PIN_L2_IOMUX                                 (IOMUX_PINCM59)
/* Defines for PIN_L3: GPIOA.22 with pinCMx 47 on package pin 18 */
#define GPIO_Follow_PIN_L3_PORT                                          (GPIOA)
#define GPIO_Follow_PIN_L3_PIN                                  (DL_GPIO_PIN_22)
#define GPIO_Follow_PIN_L3_IOMUX                                 (IOMUX_PINCM47)
/* Defines for PIN_R4: GPIOA.10 with pinCMx 21 on package pin 56 */
#define GPIO_Follow_PIN_R4_PORT                                          (GPIOA)
#define GPIO_Follow_PIN_R4_PIN                                  (DL_GPIO_PIN_10)
#define GPIO_Follow_PIN_R4_IOMUX                                 (IOMUX_PINCM21)
/* Defines for PIN_L4: GPIOA.11 with pinCMx 22 on package pin 57 */
#define GPIO_Follow_PIN_L4_PORT                                          (GPIOA)
#define GPIO_Follow_PIN_L4_PIN                                  (DL_GPIO_PIN_11)
#define GPIO_Follow_PIN_L4_IOMUX                                 (IOMUX_PINCM22)

/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_PWM_Car_init(void);
void SYSCFG_DL_PWM_Sg_init(void);
void SYSCFG_DL_TIMER_Ultrasonic_init(void);
void SYSCFG_DL_TIMER_10ms_init(void);
void SYSCFG_DL_I2C_OLED_init(void);
void SYSCFG_DL_I2C_MPU6050_init(void);
void SYSCFG_DL_UART_0_init(void);
void SYSCFG_DL_UART_1_init(void);
void SYSCFG_DL_UART_2_init(void);
void SYSCFG_DL_UART_3_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
