#ifndef _ENCODER_H__
#define _ENCODER_H__



void Encoder_Init();



#endif
















