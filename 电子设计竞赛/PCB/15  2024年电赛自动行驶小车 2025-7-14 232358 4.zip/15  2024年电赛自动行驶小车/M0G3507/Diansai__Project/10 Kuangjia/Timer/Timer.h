#ifndef _TIMER_H__
#define _TIMER_H__

void Timer_G0_10ms_Init();//10ms中断初始化




#endif















