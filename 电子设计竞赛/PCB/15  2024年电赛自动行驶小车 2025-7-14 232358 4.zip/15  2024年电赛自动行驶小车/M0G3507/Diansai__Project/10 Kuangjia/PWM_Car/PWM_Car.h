#ifndef _PWM_CAR_H__
#define _PWM_CAR_H__


void PWM_Car_Init();
void Right_PWM(int16_t Compare);
void Left_PWM(int16_t Compare);
void Set_Freq(uint32_t freq);//设置输出频率



#endif




















