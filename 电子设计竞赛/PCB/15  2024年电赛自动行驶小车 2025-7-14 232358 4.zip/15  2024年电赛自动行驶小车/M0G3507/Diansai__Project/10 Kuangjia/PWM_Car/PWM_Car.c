#include "ti_msp_dl_config.h"
#include "PWM_Car.h"

void PWM_Car_Init()
{
  DL_TimerA_startCounter(PWM_Car_INST);
}

void Right_PWM(int16_t Compare)
{
   DL_TimerA_setCaptureCompareValue(PWM_Car_INST, Compare, DL_TIMER_CC_0_INDEX);//改变右轮占空比
}

void Left_PWM(int16_t Compare)
{
   DL_TimerA_setCaptureCompareValue(PWM_Car_INST, Compare, DL_TIMER_CC_1_INDEX);//改变左轮占空比
}

void Set_Freq(uint32_t freq)//设置输出频率
{
  uint32_t period;
  period = PWM_Car_INST_CLK_FREQ / freq;
  DL_Timer_setLoadValue(PWM_Car_INST, period);//设置定时器重装载值
}











