#include "ti_msp_dl_config.h"
#include "Servo.h"

void Servo_Init()
{
  DL_TimerA_startCounter(PWM_Sg_INST);
}

void Servo_SetAngle_1(float Angle)
{
  DL_TimerA_setCaptureCompareValue(PWM_Sg_INST, Angle / 180 *2000 + 500, DL_TIMER_CC_0_INDEX);//改变B26舵机占空比
}

void Servo_SetAngle_2(float Angle)
{
  DL_TimerA_setCaptureCompareValue(PWM_Sg_INST, Angle / 180 *2000 + 500, DL_TIMER_CC_1_INDEX);//改变B27舵机占空比
}














