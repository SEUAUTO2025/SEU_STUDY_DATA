#ifndef _SERVOL_H__
#define _SERVOL_H__


void Servo_Init();
void Servo_SetAngle_1(float Angle);
void Servo_SetAngle_2(float Angle);







#endif
























