#include "ti_msp_dl_config.h"
#include "OPENMV.h"

uint8_t Uart0_RxPack[4];//定义缓存区数组

void OPENMV_Init()
{
   NVIC_ClearPendingIRQ(UART_0_INST_INT_IRQN); //先清空中断状态
   NVIC_EnableIRQ(UART_0_INST_INT_IRQN);//使能串口0中断
}

void UART_0_INST_IRQHandler(void)
{
    static uint8_t RxState = 0;//静态变量,状态量
	static uint8_t pRxPacket = 0;//接收到哪一个?
    uint8_t RxData;

    switch (DL_UART_Main_getPendingInterrupt(UART_0_INST))
    {
        case DL_UART_MAIN_IIDX_RX:
             
	    RxData = DL_UART_Main_receiveData(UART_0_INST);
		
    if(RxState == 0)//状态1
		{
		  if(RxData == 0xFF)
			{
			  RxState = 1;//状态致1
			  pRxPacket = 0;//为状态2的数据接收位变量清0
			}
		}			
	else if(RxState == 1)//状态1
		{
          Uart0_RxPack[pRxPacket] = RxData;
          pRxPacket ++;
			if(pRxPacket >= 4)
			{
			 RxState = 2;
			}
		}
	else if(RxState == 2)//状态2
		{
	    if(RxData == 0xFE)
			{
			   RxState = 0;
			}
  	    }
            //DL_UART_Main_transmitData(UART_0_INST, Data_Uart0);
            break;
        default:
            break;
    }
}














