#include "ti_msp_dl_config.h"
#include "Key.h"

uint8_t Key_Value;

uint8_t Key_GetValue()
{
    if(!DL_GPIO_readPins(GPIO_Key_PORT,GPIO_Key_PIN_S1_PIN))
       {
         Key_Value = 1;
       }
    else if(!DL_GPIO_readPins(GPIO_Key_PORT,GPIO_Key_PIN_S2_PIN))
       {
         Key_Value = 2;
       }
    else if(!DL_GPIO_readPins(GPIO_Key_PORT,GPIO_Key_PIN_S3_PIN))
       {
         Key_Value = 3;
       }
    else if(!DL_GPIO_readPins(GPIO_Key_PORT,GPIO_Key_PIN_S4_PIN))
       {
         Key_Value = 4;
       }
    else
       {
          Key_Value = 0;
       }
    
    return Key_Value;
}







