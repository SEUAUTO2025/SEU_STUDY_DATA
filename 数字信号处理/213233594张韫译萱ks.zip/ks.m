clear; close all; clc;

%% 1. 参数定义
Fs = 8000;          % 采样频率
fp = 3400;          % 通带截止频率
fs_stop = 4000;     % 阻带截止频率 (Nyquist)
Rp = 0.5;           % 通带最大波动 (dB)
As = 40;            % 阻带最小衰减 (dB)

%% 2. 滤波器阶数计算
% 采用双线性变换法的设计思路计算阶数
wp = 2 * pi * fp;
ws = 2 * pi * fs_stop;
T = 1/Fs;

% 预畸变处理：将数字频率映射为模拟频率
Omega_p = (2/T) * tan(wp * T / 2);
% 由于 fs_stop = Fs/2，对应的数字角频率为 pi，tan(pi/2) -> Inf
% 理论上 Omega_s -> Inf，切比雪夫I型在无穷远处衰减最大。
% 此时阶数主要由通带波纹和截止特性决定，或取一接近Nyquist的频率计算。
% 根据文档分析及计算，取 N = 5。
N = 5;

fprintf('设计阶数 N = %d\n', N);
fprintf('通带波动参数 Rp = %.1f dB\n', Rp);

%% 3. 模拟原型设计 (Chebyshev I)
% 获取归一化(Omega_p=1)的模拟低通滤波器极点、零点和增益
[z0, p0, k0] = cheb1ap(N, Rp);
[b0, a0] = zp2tf(z0, p0, k0);

%% 4. 方法一：双线性变换法 (Bilinear Transformation)
% 步骤1：模拟域去归一化 (s -> s/Omega_p)
[b_a1, a_a1] = lp2lp(b0, a0, Omega_p);

% 步骤2：双线性变换 (s -> (2/T)*(1-z^-1)/(1+z^-1))
[b_z1, a_z1] = bilinear(b_a1, a_a1, Fs);

%脉冲响应不变法
% 步骤1：模拟域去归一化
% 注意：脉冲响应不变法模拟频率与数字频率线性对应，Omega = omega/T = 2*pi*f
Omega_p_imp = 2 * pi * fp; 
[b_a2, a_a2] = lp2lp(b0, a0, Omega_p_imp);

% 步骤2：脉冲响应不变变换
[b_z2, a_z2] = impinvar(b_a2, a_a2, Fs);

%% 6. 频率响应计算与绘图
% 计算频率响应
[H1, w] = freqz(b_z1, a_z1, 4096, Fs);
[H2, ~] = freqz(b_z2, a_z2, 4096, Fs);

% 幅度响应 (dB)
mag1 = 20*log10(abs(H1));
mag2 = 20*log10(abs(H2));

% 绘图1：两种方法的幅频响应对比
figure('Color', 'w');
plot(w, mag1, 'b', 'LineWidth', 1.5); hold on;
plot(w, mag2, 'r--', 'LineWidth', 1.5);
grid on;
legend('双线性变换法', '脉冲响应不变法', 'Location', 'SouthWest');
title('两种设计方法的频率响应比较 (Chebyshev I, N=5)');
xlabel('频率 (Hz)');
ylabel('幅度 (dB)');
axis([0 4000 -100 10]);

% 绘制指标限制框
xline(fp, 'g--', 'LineWidth', 1);
yline(-Rp, 'g--', 'LineWidth', 1);
yline(-As, 'k-.', 'LineWidth', 1);
text(fp, -10, ' f_p', 'Color', 'g');
text(100, -As-5, ' A_s = 40dB', 'Color', 'k');

% 保存对比图
print(gcf, 'iir_comparison.png', '-dpng', '-r300');

% 绘图2：零极点分布 (双线性变换法)
figure('Color', 'w');
zplane(b_z1, a_z1);
title('数字滤波器零极点分布 (双线性变换法)');
% 保存零极点图
print(gcf, 'iir_zeroplot.png', '-dpng', '-r300');

%% 7. 结果验证与输出
disp('--------------------------------------------------');
disp('双线性变换法设计结果 (H1):');
pass_rip = max(mag1(w<=fp)) - min(mag1(w<=fp));
stop_att_Nyquist = -mag1(end); % 4kHz处衰减

fprintf('通带实际波纹: %.4f dB (要求 %.1f dB)\n', pass_rip, Rp);
fprintf('4kHz处衰减: %.4f dB (理论上无穷大)\n', stop_att_Nyquist);

if pass_rip <= Rp
    disp('>> 结论：双线性变换法设计满足通带指标。');
else
    disp('>> 结论：双线性变换法设计不满足指标，需检查。');
end

disp('--------------------------------------------------');
disp('脉冲响应不变法设计结果 (H2):');
% 检查混叠影响
stop_att_imp = -mag2(end);
fprintf('4kHz处衰减: %.4f dB\n', stop_att_imp);
if stop_att_imp < As
    disp('>> 结论：脉冲响应不变法在阻带衰减不足，存在混叠现象。');
end

%% 8. 显示传递函数系数
disp('--------------------------------------------------');
disp('双线性变换法传递函数系数 (归一化):');
disp('Numerator (b):'); disp(b_z1);
disp('Denominator (a):'); disp(a_z1);