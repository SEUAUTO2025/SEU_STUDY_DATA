% FIR数字低通滤波器设计 (窗函数法)
% 姓名：张韫译萱 学号：213233594

clear; close all; clc;

%% 1. 设计指标
wp = 0.2 * pi;  % 通带截止
ws = 0.3 * pi;  % 阻带截止
As = 40;        % 阻带最小衰减 (dB)

%% 2. 计算阶数 (海明窗)
delta_w = ws - wp;
% 估算公式: N = 6.6*pi / delta_w
N_est = ceil(6.6 * pi / delta_w);

% 保证N为奇数，确保I型线性相位
if mod(N_est, 2) == 0
    N = N_est + 1;
else
    N = N_est;
end
fprintf('滤波器阶数 N = %d\n', N);

%% 3. 理想低通单位脉冲响应 hd(n)
wc = (wp + ws) / 2;
tau = (N - 1) / 2; 
n = 0 : N-1;

hd = zeros(1, N);
for i = 1:N
    if n(i) == tau
        hd(i) = wc / pi;
    else
        hd(i) = sin(wc * (n(i) - tau)) / (pi * (n(i) - tau));
    end
end

%% 4. 加窗 (Hamming Window)
w_win = (0.54 - 0.46 * cos(2 * pi * n / (N - 1)));
h = hd .* w_win;

% 输出滤波器系数 (H(z)多项式系数)
fprintf('\n滤波器系数 h(n) (即 H(z) ):\n');
fprintf('前5项: %10.6f %10.6f %10.6f %10.6f %10.6f ...\n', h(1:5));
fprintf('中间项: %10.6f ...\n', h(ceil(N/2)));
fprintf('后5项: ... %10.6f %10.6f %10.6f %10.6f %10.6f\n', h(end-4:end));

%% 5. 仿真与绘图
[H, w] = freqz(h, 1, 1024);

figure('Color', 'w');

% 幅频响应
subplot(2,1,1);
plot(w/pi, 20*log10(abs(H)), 'b', 'LineWidth', 1.5); grid on;
title(['幅频响应 (N=', num2str(N), ')']);
xlabel('归一化频率 (\times\pi rad/sample)'); 
ylabel('幅度 (dB)');
axis([0 1 -80 10]);
yline(-As, '--r', '阻带限');
xline(wp/pi, '--k'); xline(ws/pi, '--k');

% 相频响应
subplot(2,1,2);
plot(w/pi, angle(H), 'b', 'LineWidth', 1.5); grid on;
title('相频响应');
xlabel('归一化频率 (\times\pi rad/sample)'); 
ylabel('相位 (rad)');
axis([0 1 -pi pi]);

%% 6. 验证
% 传入向量避免freqz标量歧义
H_ws = freqz(h, 1, [ws, 0]); 
stopband_att = -20*log10(abs(H_ws(1)));

fprintf('\n阻带截止处衰减: %.2f dB (要求 > %.0f dB)\n', stopband_att, As);
if stopband_att >= As
    fprintf('设计满足要求。\n');
end