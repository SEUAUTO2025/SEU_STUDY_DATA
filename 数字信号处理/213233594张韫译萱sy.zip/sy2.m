% 213233594张韫译萱sy2.m
% 基于双线性变换法的Butterworth低通滤波器

clear;
close all;
clc;

% 1. 滤波器技术指标
% 采样频率
Fs = 1000;              % 采样频率 (Hz)
T = 1/Fs;               % 采样周期

% 边界频率 (Hz)
fp = 200;               % 通带截止频率
fs = 300;               % 阻带截止频率

% 衰减指标 (dB)
Rp = 1;                 % 通带最大衰减
As = 20;                % 阻带最小衰减

disp('【1. 技术指标】');
fprintf('采样频率 Fs = %d Hz\n', Fs);
fprintf('通带截止频率 fp = %d Hz\n', fp);
fprintf('阻带截止频率 fs = %d Hz\n', fs);
fprintf('通带最大衰减 Rp = %d dB\n', Rp);
fprintf('阻带最小衰减 As = %d dB\n', As);

% 2. 频率预畸变
% 将数字角频率转换为模拟角频率
% 预畸变公式: Omega = (2/T) * tan(omega_digital * T / 2)

wd_p = 2 * pi * fp;     % 数字通带角频率
wd_s = 2 * pi * fs;     % 数字阻带角频率

Omega_p = (2/T) * tan(wd_p * T / 2);
Omega_s = (2/T) * tan(wd_s * T / 2);

disp(' ');
disp('【2. 频率预畸变】');
fprintf('模拟通带频率 Omega_p = %.4f rad/s\n', Omega_p);
fprintf('模拟阻带频率 Omega_s = %.4f rad/s\n', Omega_s);

% 3. 确定模拟滤波器阶数 N 和截止频率 Omega_c
% 巴特沃斯滤波器阶数公式
% N >= lg(sqrt((10^(0.1*As)-1)/(10^(0.1*Rp)-1))) / lg(Omega_s/Omega_p)

lambda_sp = Omega_s / Omega_p;
k_sp = sqrt((10^(0.1*As) - 1) / (10^(0.1*Rp) - 1));
N_exact = log10(k_sp) / log10(lambda_sp);
N = ceil(N_exact);

% 计算3dB截止频率 Omega_c
% 按照通带指标计算
Omega_c = Omega_p / ((10^(0.1*Rp) - 1)^(1/(2*N)));

disp(' ');
disp('【3. 模拟滤波器参数】');
fprintf('计算阶数 N_exact = %.4f\n', N_exact);
fprintf('取整阶数 N = %d\n', N);
fprintf('3dB截止频率 Omega_c = %.4f rad/s\n', Omega_c);

% 4. 构造模拟低通原型滤波器 H(s)
% 巴特沃斯极点分布
% p_k = Omega_c * exp(j * (pi/2 + (2k-1)/(2N)*pi))

pk = zeros(N, 1);
for k = 1:N
    theta_k = pi/2 + (2*k - 1)/(2*N) * pi;
    pk(k) = Omega_c * exp(1j * theta_k);
end

% 传递函数 H(s) = product(-pk) / product(s - pk) 
% 对于巴特沃斯滤波器，分子是 Omega_c^N
[b_s, a_s] = zp2tf([], pk, Omega_c^N);

disp(' ');
disp('【4. 模拟滤波器传递函数 H(s)】');
disp('分子系数 b_s:'); disp(b_s);
disp('分母系数 a_s:'); disp(a_s);

% 验证模拟滤波器特性
w_analog = linspace(0, Omega_s*1.5, 500);
H_s = freqs(b_s, a_s, w_analog);
figure(1);
plot(w_analog/(2*pi), 20*log10(abs(H_s)));
title('模拟原型滤波器幅频响应');
xlabel('频率 (Hz)'); ylabel('幅度 (dB)');
grid on;

% 5. 双线性变换法设计数字滤波器 H(z)
% 使用 bilinear 函数进行变换
[b_z, a_z] = bilinear(b_s, a_s, Fs);

disp(' ');
disp('【5. 数字滤波器传递函数 H(z)】');
disp('分子系数 b_z:'); disp(b_z);
disp('分母系数 a_z:'); disp(a_z);

% 6. 仿真结果验证
% 计算幅频响应和相频响应
[H_z, f] = freqz(b_z, a_z, 1024, Fs);
mag_z = 20*log10(abs(H_z));
phase_z = angle(H_z) * 180/pi;

% 绘制图形
figure(2);
subplot(2,1,1);
plot(f, mag_z, 'LineWidth', 1.5);
hold on;
% 绘制指标辅助线
yline(-Rp, 'r--', '通带衰减');
yline(-As, 'g--', '阻带衰减');
xline(fp, 'r--', 'fp');
xline(fs, 'g--', 'fs');

title(['IIR数字低通滤波器幅频响应 (N=', num2str(N), ')']);
xlabel('频率 (Hz)');
ylabel('幅度 (dB)');
ylim([-60, 5]);
grid on;

subplot(2,1,2);
plot(f, phase_z, 'LineWidth', 1.5);
title('相频响应');
xlabel('频率 (Hz)');
ylabel('相位 (度)');
grid on;

% 绘制零极点图
figure(3);
zplane(b_z, a_z);
title('数字滤波器零极点分布');
grid on;

% 7. 结论
% 检查是否满足设计指标
passband_check = min(mag_z(f <= fp)) >= -Rp;
stopband_check = max(mag_z(f >= fs)) <= -As;

disp(' ');
disp('【6. 验证结论】');
if passband_check && stopband_check
    disp('结果：设计满足通带和阻带指标要求。');
else
    disp('结果：设计不满足指标要求，请检查参数。');
    fprintf('通带最小增益: %.4f dB (要求 >= -%.4f dB)\n', min(mag_z(f <= fp)), Rp);
    fprintf('阻带最大增益: %.4f dB (要求 <= -%.4f dB)\n', max(mag_z(f >= fs)), As);
end